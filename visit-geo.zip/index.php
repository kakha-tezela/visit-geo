<?php 
defined('_JEXEC') or die ('Restricted access');
 $app	= JFactory::getApplication();
$doc = JFactory::getDocument();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
<jdoc:include type="head" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Add the site description here" />
<meta  name="keywords" content="First keyword, second keyword," />
<?php $template_path = JURI::base() . 'templates/' . $app->getTemplate(); ?>
<?php JLoader::import( 'joomla.version' );
$version = new JVersion();
if (version_compare( $version->RELEASE, '2.5', '<=')) {
if(JFactory::getApplication()->get('jquery') !== true) {
$document = JFactory::getDocument();
JHtml::script(JURI::base() . "templates/". $app->getTemplate() ."/jquery.js");
}
} else {
JHtml::_('jquery.framework');
} ?>
<script type="text/javascript">
jQuery(document).ready(function(){
var inputs = document.getElementsByTagName('input');
for (a = 0; a < inputs.length; a++) {
if (inputs[a].type == "checkbox") {
var id = inputs[a].getAttribute("id");
if (id==null){
id=  "checkbox" +a;
}
inputs[a].setAttribute("id",id);
var container = document.createElement('div');
container.setAttribute("class", "ttr_checkbox");
var label = document.createElement('label');
label.setAttribute("for", id);
jQuery(inputs[a]).wrap(container).after(label);
}
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var inputs = document.getElementsByTagName('input');
for (a = 0; a < inputs.length; a++) {
if (inputs[a].type == "radio") {
var id = inputs[a].getAttribute("id");
if (id==null){
id=  "radio" +a;
}
inputs[a].setAttribute("id",id);
var container = document.createElement('div');
container.setAttribute("class", "ttr_radio");
var label = document.createElement('label');
label.setAttribute("for", id);
jQuery(inputs[a]).wrap(container).after(label);
}
}
});
</script>
<script type="text/javascript">
window.addEvent('domready', function() {
Element.implement({
hide: function() {
this.setStyle('display','');
}
});
});
</script>
<?php
if (version_compare( $version->RELEASE, '2.5', '<')) {
JHtml::_('jquery.ui');
}
$doc = JFactory::getDocument();
unset($this->_scripts[JURI::root(true).'/media/jui/js/bootstrap.min.js']);
 $doc->addScript(JURI::base() .'/templates/' . $this->template . '/bootstrap.min.js', 'text/javascript');
$doc->addStyleSheet('templates/'.$this->template.'/css/bootstrap.css');
$doc->addStyleSheet('templates/'.$this->template.'/css/template.css');
?>
<script type="text/javascript" src="<?php echo $template_path?>/totop.js">
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var window_height =  Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
var body_height = jQuery(document.body).height();
var content = jQuery("#ttr_content_and_sidebar_container");
if(body_height < window_height){
differ = (window_height - body_height);
content_height = content.height() + differ;
jQuery("#ttr_content_and_sidebar_container").css("min-height", content_height+"px");
}
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('#nav-expander').on('click',function(e){
e.preventDefault();
jQuery('body').toggleClass('nav-expanded');
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('ul.ttr_menu_items.nav li [data-toggle=dropdown]').on('click', function() {
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0)
if(window_width > 1025){
window.location.href = jQuery(this).attr('href'); 
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('ul.ttr_vmenu_items.nav li [data-toggle=dropdown]').on('click', function() {
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0)
if(window_width > 1025){
window.location.href = jQuery(this).attr('href'); 
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('.ttr_menu_items ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { 
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
if(window_width < 1025){
event.preventDefault();
event.stopPropagation();
jQuery(this).parent().siblings().removeClass('open');
jQuery(this).parent().toggleClass(function() {
if (jQuery(this).is(".open") ) {
window.location.href = jQuery(this).children("[data-toggle=dropdown]").attr('href'); 
return "";
} else {
return "open";
}
});
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
jQuery('.ttr_vmenu_items ul.dropdown-menu [data-toggle=dropdown]').on('click', function(event) { 
var window_width =  Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
if(window_width < 1025){
event.preventDefault();
event.stopPropagation();
jQuery(this).parent().siblings().removeClass('open');
jQuery(this).parent().toggleClass(function() {
if (jQuery(this).is(".open") ) {
window.location.href = jQuery(this).children("[data-toggle=dropdown]").attr('href'); 
return "";
} else {
return "open";
}
});
}
});
});
</script>
<script type="text/javascript">
jQuery(document).ready(function(){
var objects = ['iframe', 'video','object'];
for(var i = 0 ; i < objects.length ; i++){
if (jQuery(objects[i]).length > 0) {
jQuery(objects[i]).addClass('embed-responsive-item');
jQuery(objects[i]).parent().addClass('embed-responsive embed-responsive-16by9');
jQuery(".embed-responsive-16by9").css("padding-bottom","56.25%");
}
}
});
</script>
<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/system/css/system.css" type="text/css" />
<!--[if lte IE 8]>
<link rel="stylesheet"  href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/menuie.css" type="text/css"/>
<link rel="stylesheet"  href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/vmenuie.css" type="text/css"/>
<![endif]-->
<script type="text/javascript" src="<?php echo $template_path?>/prefixfree.min.js">
</script>
<!--[if IE 7]>
<style type="text/css" media="screen">
#ttr_vmenu_items  li.ttr_vmenu_items_parent {display:inline;}
</style>
<![endif]-->
<!--[if lt IE 9]>
<script type="text/javascript" src="<?php echo $template_path?>/html5shiv.js">
</script>
<script type="text/javascript" src="<?php echo $template_path?>/respond.min.js">
</script>
<![endif]-->
</head>
<body>
<a href="#" class="back-to-top"><img alt="Back to Top" src="<?php echo $template_path?>/images/gototop.png"/></a>
<div id="ttr_page"class="container">
<div class="ttr_banner_menu">
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php if ($this->countModules('Menu')):?>
<nav id="ttr_menu" class="navbar-default navbar">
<div id="ttr_menu_inner_in">
<div class="menuforeground">
</div>
<div id="navigationmenu">
<div class="navbar-header">
<button id="nav-expander" data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
<span class="sr-only">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
<span class="icon-bar">
</span>
</button>
<img src="<?php echo (JURI::base() . 'templates/' . $app->getTemplate().'/menulogo.png')?>" class="ttr_menu_logo" alt="Menulogo" />
</div>
<div class="menu-center collapse navbar-collapse">
<jdoc:include type="modules" name="Menu"/>
</div>
</div>
</div>
</nav>
<?php endif; ?>
<div class="ttr_banner_menu">
</div>
<div id="ttr_content_and_sidebar_container">
<div id="ttr_content">
<div id="ttr_content_margin">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<?php
if(  $this->countModules('contentPosition')):
?>
<div class="contenttopcolumn0">
<?php
$showcolumn= $this->countModules('contentPosition');
?>
<?php if($showcolumn): ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12">
<div class="topcolumn1">
<jdoc:include type="modules" name="contentPosition" style="<?php if(($this->params->get('contentposition') == 'block') || ($this->params->get('contentposition') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
</div>
</div>
<?php else: ?>
<div class="cell1 col-lg-12 col-md-12 col-sm-12  col-xs-12"  style="background-color:transparent;">
&nbsp;
</div>
<?php endif; ?>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<?php endif; ?>
<jdoc:include type="message" style="width:100%;"/>
<jdoc:include type="component" />
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</div>
<div style="clear:both;">
</div>
</div>
</div>
</div>
<?php if ($this->countModules('debug')){ ?>
<jdoc:include type="modules" name="debug" style="<?php if(($this->params->get('debug') == 'block') || ($this->params->get('debug') == Null)): echo "block"; else: echo "xhtml"; endif;?>"/>
<?php } ?>
</body>
</html>
